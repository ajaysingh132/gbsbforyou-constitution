const auth = supabase.auth;

async function signIn(email,password){
  return await auth.signInWithPassword({email,password});
}
async function signOut(){
  return await auth.signOut();
}
async function getCurrentUser(){
  const {data,error}=await auth.getUser();
  return {user:data?.user ?? null,error};
}
async function getCurrentProfile(){
  const {user,error:userError}=await getCurrentUser();
  if(userError || !user) return {profile:null,error:userError};
  const {data,error}=await supabase.from("users").select("id,full_name,email,role").eq("id",user.id).single();
  return {profile:data ?? null,error};
}
window.DigitalParliamentAuth={signIn,signOut,getCurrentUser,getCurrentProfile};

document.addEventListener("DOMContentLoaded",()=>{
 const form=document.getElementById("login-form");
 if(!form)return;
 const status=document.getElementById("login-status");
 form.addEventListener("submit",async e=>{
   e.preventDefault();
   status.textContent="Signing in…";
   const {error}=await signIn(document.getElementById("email").value.trim(),document.getElementById("password").value);
   if(error){status.textContent=error.message;return;}
   status.textContent="Login successful. Opening dashboard…";
   window.location.href="dashboard.html";
 });
});
