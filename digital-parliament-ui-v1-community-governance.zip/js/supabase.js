/*
 * Configure only the publishable Supabase key here.
 * Never place a service-role or secret key in this file.
 *
 * The project URL/key below are retained from the existing UI configuration.
 * Verify them before production deployment.
 */
const SUPABASE_URL = "https://dvsdqnhjucguavevcfjq.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ZAtw7wfzfUAve2C-22qepA_vUMRDxpT";
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
