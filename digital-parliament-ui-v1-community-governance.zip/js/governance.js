/*
 * UI-only governance helpers.
 * Live data must be loaded only after the approved Supabase schema/RLS
 * is finalized. No fake membership, election or leadership data is generated.
 */
window.DigitalParliamentGovernance = {
  principles: {
    localAutonomy: true,
    centralCoordination: true,
    humanAuthority: true,
    aiDecisionAuthority: false
  }
};
