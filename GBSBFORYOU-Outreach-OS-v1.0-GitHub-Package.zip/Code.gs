const SHEETS={LOG:'Outreach_Log'};
function doGet(e){return json_({ok:true,service:'GBSBFORYOU Outreach OS',version:'1.0',action:e.parameter.action||'ping'})}
function doPost(e){
  try{
    const p=JSON.parse(e.postData.contents||'{}');
    if(p.action!=='send')return json_({ok:false,message:'Unknown action'});
    const contacts=(p.contacts||[]).slice(0,10);
    const ss=SpreadsheetApp.getActive();
    const sh=ss.getSheetByName(SHEETS.LOG)||ss.insertSheet(SHEETS.LOG);
    if(sh.getLastRow()===0)sh.appendRow(['Timestamp','Contact ID','Name','Organization','Email','Subject','Status','Message']);
    let sent=0,errors=0;
    contacts.forEach(c=>{
      try{
        if(!c.email)throw new Error('Missing email');
        GmailApp.sendEmail(String(c.email),String(p.subject||''),String(p.body||''));
        sh.appendRow([new Date(),c.id||'',c.name||'',c.org||'',c.email,p.subject||'','SENT','']);
        sent++;
      }catch(err){
        sh.appendRow([new Date(),c.id||'',c.name||'',c.org||'',c.email,p.subject||'','ERROR',String(err)]);
        errors++;
      }
    });
    return json_({ok:true,sent,errors,message:`Sent ${sent}; errors ${errors}`});
  }catch(err){return json_({ok:false,message:String(err)})}
}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON)}
